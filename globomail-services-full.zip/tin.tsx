'use client';

import Link from 'next/link';

export default function TINService() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('TIN certificate request submitted!');
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 md:p-6">
      <header className="mb-6">
        <Link href="/dashboard" className="text-blue-400 hover:text-blue-300 flex items-center gap-1">
          ← Back to Dashboard
        </Link>
        <h1 className="text-2xl font-bold mt-2">TIN Certificate</h1>
        <p className="text-gray-400">Get Tax Identification Number (TIN) from FIRS</p>
      </header>

      <div className="max-w-2xl bg-gray-800 rounded-xl border border-gray-700 p-6">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-medium mb-2">Applicant Type</label>
            <select className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg">
              <option>Individual</option>
              <option>Business (Sole Proprietor)</option>
              <option>Company (Ltd, Plc, etc.)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Full Name / Business Name</label>
            <input
              type="text"
              placeholder="Globomail Tech Ltd"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Email</label>
            <input
              type="email"
              placeholder="tax@company.com"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Phone</label>
            <input
              type="tel"
              placeholder="+234 803 000 0000"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-green-600 hover:bg-green-700 rounded-lg font-medium"
          >
            Request TIN Certificate
          </button>
        </form>
      </div>
    </div>
  );
}