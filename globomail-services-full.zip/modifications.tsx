'use client';

import Link from 'next/link';

export default function ModificationsService() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Modification request submitted!');
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 md:p-6">
      <header className="mb-6">
        <Link href="/dashboard" className="text-blue-400 hover:text-blue-300 flex items-center gap-1">
          ← Back to Dashboard
        </Link>
        <h1 className="text-2xl font-bold mt-2">Modifications</h1>
        <p className="text-gray-400">Update names, DOB, or other details on official records</p>
      </header>

      <div className="max-w-2xl bg-gray-800 rounded-xl border border-gray-700 p-6">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-medium mb-2">Document Type</label>
            <select className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg">
              <option>National ID</option>
              <option>BVN</option>
              <option>Voter’s Card</option>
              <option>CAC Records</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Current Full Name</label>
            <input
              type="text"
              placeholder="John Doe"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">New Full Name</label>
            <input
              type="text"
              placeholder="Jonathan Doe"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Supporting Documents</label>
            <div className="text-sm text-gray-400">
              Upload affidavit, court order, or newspaper publication.
            </div>
            <input
              type="file"
              className="mt-2 w-full text-sm"
              accept=".pdf,.jpg,.jpeg,.png"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-green-600 hover:bg-green-700 rounded-lg font-medium"
          >
            Request Modification
          </button>
        </form>
      </div>
    </div>
  );
}