'use client';

import Link from 'next/link';

export default function PersonalizationService() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Personalization request submitted!');
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 md:p-6">
      <header className="mb-6">
        <Link href="/dashboard" className="text-blue-400 hover:text-blue-300 flex items-center gap-1">
          ← Back to Dashboard
        </Link>
        <h1 className="text-2xl font-bold mt-2">Personalization</h1>
        <p className="text-gray-400">Customize IDs, certificates, or documents</p>
      </header>

      <div className="max-w-2xl bg-gray-800 rounded-xl border border-gray-700 p-6">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-medium mb-2">Service Type</label>
            <select className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg">
              <option>National ID Card Laser Engraving</option>
              <option>CAC Certificate Custom Seal</option>
              <option>Police Clearance Custom Format</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Details / Notes</label>
            <textarea
              placeholder="Specify personalization request..."
              rows={4}
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-green-600 hover:bg-green-700 rounded-lg font-medium"
          >
            Request Personalization
          </button>
        </form>
      </div>
    </div>
  );
}