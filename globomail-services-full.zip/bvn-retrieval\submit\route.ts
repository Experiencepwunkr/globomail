// src/app/api/services/bvnr-retrieval/submit/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(req: NextRequest) {
  try {
    const { agentId, phone, nameOnBVN, dob, paymentReference } = await req.json();

    // Verify payment
    const tx = await prisma.transaction.findUnique({
      where: { reference: paymentReference },
    });
    if (!tx || tx.status !== 'success') {
      return NextResponse.json({ error: 'Invalid payment.' }, { status: 403 });
    }

    // Save submission
    const updatedTx = await prisma.transaction.update({
      where: { id: tx.id },
      data: {
        metadata: { phone, nameOnBVN, dob },
        status: 'pending', // → goes to admin
      },
    });

    return NextResponse.json({
      success: true,
      requestId: updatedTx.id,
    });
  } catch (error: any) {
    return NextResponse.json({ error: 'Submission failed.' }, { status: 500 });
  } finally {
    await prisma.$disconnect();
  }
}