'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { getAgent } from '@/lib/auth';

export default function IPEClearanceService() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const agent = getAgent();
  const router = useRouter();
  const searchParams = useSearchParams();
  const paid = searchParams.get('paid') === 'true';
  const ref = searchParams.get('ref');

  if (!agent) {
    router.push('/login');
    return null;
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const formData = new FormData(e.currentTarget);
    const data = {
      fullName: formData.get('fullName') as string,
      dob: formData.get('dob') as string,
      state: formData.get('state') as string,
      address: formData.get('address') as string,
      consent: formData.get('consent') === 'on',
      paymentReference: ref || '',
    };

    if (!data.consent) {
      setError('You must confirm consent.');
      setLoading(false);
      return;
    }

    try {
      if (!paid) {
        const payRes = await fetch('/api/payments/initiate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            agentId: agent.id,
            serviceType: 'IPE_CLEARANCE',
          }),
        });
        const payData = await payRes.json();
        if (!payRes.ok) throw new Error(payData.error);
        window.location.href = payData.authorization_url;
        return;
      }

      const res = await fetch('/api/services/ipe-clearance/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      const result = await res.json();
      if (res.ok) {
        alert('✅ IPE Clearance request submitted! Check dashboard for updates.');
        router.push('/dashboard');
      } else {
        setError(result.error || 'Submission failed.');
      }
    } catch (err: any) {
      setError(err.message || 'Network error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 md:p-6">
      <header className="mb-6">
        <Link href="/dashboard" className="text-blue-400 hover:text-blue-300 flex items-center gap-1">
          ← Back to Dashboard
        </Link>
        <h1 className="text-2xl font-bold mt-2">IPE Clearance (Instant)</h1>
        <p className="text-gray-400">
          {paid ? '✅ Payment confirmed. Submit client details.' : '₦950 — Pay to proceed.'}
        </p>
      </header>

      <div className="max-w-2xl bg-gray-800 rounded-xl border border-gray-700 p-6">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-medium mb-2">Full Name</label>
            <input
              type="text"
              name="fullName"
              placeholder="John Doe"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Date of Birth</label>
            <input
              type="date"
              name="dob"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">State of Origin</label>
            <input
              type="text"
              name="state"
              placeholder="Lagos"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Address</label>
            <textarea
              name="address"
              placeholder="123 Main St, Ikeja"
              rows={3}
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div className="flex items-start gap-2">
            <input
              type="checkbox"
              id="consent"
              name="consent"
              required
              className="mt-1 w-4 h-4"
            />
            <label htmlFor="consent" className="text-sm">
              I confirm the client granted consent for clearance.
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-3 rounded-lg font-medium ${
              loading ? 'bg-gray-600' : paid ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'
            }`}
          >
            {loading ? 'Processing...' : paid ? 'Submit Request' : 'Pay ₦950 & Submit'}
          </button>

          {error && <div className="text-red-400 text-sm">{error}</div>}
        </form>
      </div>
    </div>
  );
}