'use client';

import Link from 'next/link';

export default function SelfServiceUnlinkService() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Unlink request submitted!');
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 md:p-6">
      <header className="mb-6">
        <Link href="/dashboard" className="text-blue-400 hover:text-blue-300 flex items-center gap-1">
          ← Back to Dashboard
        </Link>
        <h1 className="text-2xl font-bold mt-2">Self Service Unlink</h1>
        <p className="text-gray-400">Unlink NIN, BVN, or phone number from another record</p>
      </header>

      <div className="max-w-2xl bg-gray-800 rounded-xl border border-gray-700 p-6">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-medium mb-2">Record Type to Unlink</label>
            <select className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg">
              <option>NIN from Phone</option>
              <option>BVN from NIN</option>
              <option>Phone from Email</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Current Identifier (e.g., NIN)</label>
            <input
              type="text"
              placeholder="12345678901"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Target Identifier (e.g., Phone)</label>
            <input
              type="text"
              placeholder="+234 803 000 0000"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div className="text-sm text-yellow-400 bg-yellow-900/30 p-3 rounded">
            ⚠️ This action is irreversible. Ensure you have authorization.
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-red-600 hover:bg-red-700 rounded-lg font-medium"
          >
            Confirm Unlink
          </button>
        </form>
      </div>
    </div>
  );
}