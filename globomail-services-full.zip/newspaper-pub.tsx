'use client';

import Link from 'next/link';

export default function NewspaperPubService() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Newspaper publication request submitted!');
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 md:p-6">
      <header className="mb-6">
        <Link href="/dashboard" className="text-blue-400 hover:text-blue-300 flex items-center gap-1">
          ← Back to Dashboard
        </Link>
        <h1 className="text-2xl font-bold mt-2">Newspaper Publication</h1>
        <p className="text-gray-400">Publish name change, lost item, company notice, etc.</p>
      </header>

      <div className="max-w-2xl bg-gray-800 rounded-xl border border-gray-700 p-6">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-medium mb-2">Publication Type</label>
            <select className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg">
              <option>Name Change</option>
              <option>Lost Item (e.g., Passport)</option>
              <option>Company Notice</option>
              <option>Correction/Clarification</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Content (Max 100 words)</label>
            <textarea
              placeholder="I, John Doe, hereby change my name to Jonathan Doe..."
              rows={4}
              maxLength={500}
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Preferred Newspaper(s)</label>
            <div className="grid grid-cols-2 gap-2 mt-1">
              {['The Guardian', 'Punch', 'Vanguard', 'ThisDay'].map((paper) => (
                <label key={paper} className="flex items-center">
                  <input type="checkbox" className="mr-2" />
                  <span>{paper}</span>
                </label>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-green-600 hover:bg-green-700 rounded-lg font-medium"
          >
            Submit for Publication
          </button>
        </form>
      </div>
    </div>
  );
}