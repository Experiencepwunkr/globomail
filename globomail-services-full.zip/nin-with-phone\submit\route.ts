import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(req: NextRequest) {
  try {
    const { agentId, nin, phone, consent, paymentReference } = await req.json();

    if (!nin || !phone || !consent) {
      return NextResponse.json({ error: 'All fields are required.' }, { status: 400 });
    }

    const tx = await prisma.transaction.findUnique({
      where: { reference: paymentReference },
    });
    if (!tx || tx.status !== 'success') {
      return NextResponse.json({ error: 'Invalid or unpaid reference.' }, { status: 403 });
    }

    const updatedTx = await prisma.transaction.update({
      where: { id: tx.id },
      data: {
        meta: { nin, phone, consent },
        status: 'pending',
      },
    });

    return NextResponse.json({
      success: true,
      requestId: updatedTx.id,
    });
  } catch (error: any) {
    return NextResponse.json({ error: 'Submission failed.' }, { status: 500 });
  } finally {
    await prisma.$disconnect();
  }
}