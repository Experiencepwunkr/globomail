'use client';

import Link from 'next/link';

export default function BirthAttestationService() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Birth Attestation request submitted!');
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 md:p-6">
      <header className="mb-6">
        <Link href="/dashboard" className="text-blue-400 hover:text-blue-300 flex items-center gap-1">
          ← Back to Dashboard
        </Link>
        <h1 className="text-2xl font-bold mt-2">Birth Attestation</h1>
        <p className="text-gray-400">Get official birth confirmation for immigration, school, etc.</p>
      </header>

      <div className="max-w-2xl bg-gray-800 rounded-xl border border-gray-700 p-6">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-medium mb-2">Child’s Full Name</label>
            <input
              type="text"
              placeholder="Jane Doe"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Date of Birth</label>
            <input
              type="date"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Place of Birth</label>
            <input
              type="text"
              placeholder="Lagos University Teaching Hospital"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Parents’ Names</label>
            <input
              type="text"
              placeholder="John & Mary Doe"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-green-600 hover:bg-green-700 rounded-lg font-medium"
          >
            Request Birth Attestation
          </button>
        </form>
      </div>
    </div>
  );
}