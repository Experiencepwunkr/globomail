'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { getAgent } from '@/lib/auth';

export default function CACService() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [proprietors, setProprietors] = useState([{}]);
  const agent = getAgent();
  const router = useRouter();
  const searchParams = useSearchParams();
  const paid = searchParams.get('paid') === 'true';
  const ref = searchParams.get('ref');

  if (!agent) {
    router.push('/login');
    return null;
  }

  const addProprietor = () => {
    setProprietors([...proprietors, {}]);
  };

  const removeProprietor = () => {
    if (proprietors.length > 1) {
      setProprietors(proprietors.slice(0, -1));
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const formData = new FormData(e.currentTarget);
    const data: any = {
      serviceType: formData.get('serviceType') as string,
      companyName1: formData.get('companyName1') as string,
      companyName2: formData.get('companyName2') as string,
      companyEmail: formData.get('companyEmail') as string,
      category: formData.get('category') as string,
      state: formData.get('state') as string,
      lga: formData.get('lga') as string,
      address: formData.get('address') as string,
      consent: formData.get('consent') === 'on',
      paymentReference: ref || '',
    };

    data.proprietors = proprietors.map((_, i) => ({
      fullName: formData.get(`proprietor_${i}_fullName`) as string,
      dob: formData.get(`proprietor_${i}_dob`) as string,
      gender: formData.get(`proprietor_${i}_gender`) as string,
      phone: formData.get(`proprietor_${i}_phone`) as string,
      nin: formData.get(`proprietor_${i}_nin`) as string,
      state: formData.get(`proprietor_${i}_state`) as string,
      lga: formData.get(`proprietor_${i}_lga`) as string,
      address: formData.get(`proprietor_${i}_address`) as string,
    }));

    if (!data.consent) {
      setError('You must confirm consent.');
      setLoading(false);
      return;
    }

    try {
      if (!paid) {
        const payRes = await fetch('/api/payments/initiate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            agentId: agent.id,
            serviceType: 'CAC',
          }),
        });
        const payData = await payRes.json();
        if (!payRes.ok) throw new Error(payData.error);
        window.location.href = payData.authorization_url;
        return;
      }

      const res = await fetch('/api/services/cac/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      const result = await res.json();
      if (res.ok) {
        alert('✅ CAC service submitted! Check dashboard for updates.');
        router.push('/dashboard');
      } else {
        setError(result.error || 'Submission failed.');
      }
    } catch (err: any) {
      setError(err.message || 'Network error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 md:p-6">
      <header className="mb-6">
        <Link href="/dashboard" className="text-blue-400 hover:text-blue-300 flex items-center gap-1">
          ← Back to Dashboard
        </Link>
        <h1 className="text-2xl font-bold mt-2">CAC Services</h1>
        <p className="text-gray-400">
          {paid ? '✅ Payment confirmed. Submit client details.' : '₦64,000 — Pay to proceed.'}
        </p>
      </header>

      <div className="max-w-4xl bg-gray-800 rounded-xl border border-gray-700 p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">Choose Service</label>
            <select
              name="serviceType"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            >
              <option value="">Select Service Type</option>
              <option value="business_name">Business Name Sole Proprietorship (₦64,000)</option>
              <option value="limited_liability">Limited Liability 1M Share (₦90,000)</option>
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Company Name 1</label>
              <input
                type="text"
                name="companyName1"
                placeholder="Globomail Tech"
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Company Name 2 (Optional)</label>
              <input
                type="text"
                name="companyName2"
                placeholder="Ltd"
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Company Email</label>
            <input
              type="email"
              name="companyEmail"
              placeholder="contact@company.com"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Category of Business</label>
            <input
              type="text"
              name="category"
              placeholder="General Merchandise"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">State</label>
              <input
                type="text"
                name="state"
                placeholder="Lagos"
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">LGA and City</label>
              <input
                type="text"
                name="lga"
                placeholder="Ikeja"
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Street Address</label>
              <input
                type="text"
                name="address"
                placeholder="123 Main St"
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg"
                required
              />
            </div>
          </div>

          {/* Proprietors */}
          <div className="border-t border-gray-700 pt-6">
            <h3 className="text-lg font-semibold mb-4">Proprietor Information</h3>
            {proprietors.map((_, i) => (
              <div key={i} className="mb-6 p-4 bg-gray-700 rounded-lg">
                <h4 className="font-medium mb-3">Proprietor {i + 1}</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Full Name</label>
                    <input
                      type="text"
                      name={`proprietor_${i}_fullName`}
                      placeholder="John Doe"
                      className="w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Date of Birth</label>
                    <input
                      type="date"
                      name={`proprietor_${i}_dob`}
                      className="w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Gender</label>
                    <select
                      name={`proprietor_${i}_gender`}
                      className="w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded"
                      required
                    >
                      <option>-- Select Gender --</option>
                      <option>Male</option>
                      <option>Female</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Phone Number</label>
                    <input
                      type="tel"
                      name={`proprietor_${i}_phone`}
                      placeholder="+234 803 000 0000"
                      className="w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">NIN Number</label>
                    <input
                      type="text"
                      name={`proprietor_${i}_nin`}
                      placeholder="12345678901"
                      className="w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">State</label>
                    <input
                      type="text"
                      name={`proprietor_${i}_state`}
                      placeholder="Lagos"
                      className="w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">LGA and City</label>
                    <input
                      type="text"
                      name={`proprietor_${i}_lga`}
                      placeholder="Ikeja"
                      className="w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Street Address</label>
                    <input
                      type="text"
                      name={`proprietor_${i}_address`}
                      placeholder="123 Main St"
                      className="w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded"
                      required
                    />
                  </div>
                </div>
              </div>
            ))}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={addProprietor}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded text-sm"
              >
                + Add Another Proprietor
              </button>
              <button
                type="button"
                onClick={removeProprietor}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 rounded text-sm"
                disabled={proprietors.length <= 1}
              >
                - Remove Last Proprietor
              </button>
            </div>
          </div>

          <div className="flex items-start gap-2">
            <input
              type="checkbox"
              id="consent"
              name="consent"
              required
              className="mt-1 w-4 h-4"
            />
            <label htmlFor="consent" className="text-sm">
              By checking this box, you confirm that every information you submit is valid and correct.
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-3 rounded-lg font-medium ${
              loading ? 'bg-gray-600' : paid ? 'bg-green-600 hover:bg-green-700' : 'bg-blue-600 hover:bg-blue-700'
            }`}
          >
            {loading ? 'Processing...' : paid ? 'Submit Request' : 'Pay ₦64,000 & Submit'}
          </button>

          {error && <div className="text-red-400 text-sm">{error}</div>}
        </form>
      </div>
    </div>
  );
}